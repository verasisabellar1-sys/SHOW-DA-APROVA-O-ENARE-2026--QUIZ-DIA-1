TUTORIAL — PUBLICAR O JOGO NO GITHUB PAGES (MODO FÁCIL)

O QUE VOCÊ VAI FAZER
- Subir 3 arquivos: index.html, 404.html e (opcional) jogo_dia1_lei8080.html
- Ativar o GitHub Pages no repositório para gerar um LINK público do jogo.

PASSO A PASSO (PELO CELULAR OU PC)
1) Crie uma conta no GitHub: https://github.com  (se já tiver, faça login)
2) Clique em [+] > "New repository".
   • Nome do repositório: enare-dia1 (pode ser outro)
   • Visibility: Public
   • Create repository
3) Na página do repositório, clique em "Add file" > "Upload files".
4) Envie estes 3 arquivos (do ZIP que você baixou):
   • index.html      (ABRE o jogo na raiz /)
   • 404.html        (página de fallback)
   • jogo_dia1_lei8080.html  (cópia do jogo, opcional)
   • Clique em "Commit changes".
5) Ativar o Pages:
   • Vá em Settings > Pages
   • Em "Build and deployment", em "Source" escolha: "Deploy from a branch"
   • Em "Branch": escolha "main" e "/ (root)"
   • Clique "Save"
6) Aguarde 1–2 minutos e atualize a página. O GitHub vai mostrar a URL do site, algo como:
   https://SEU-USUARIO.github.io/enare-dia1/
7) Teste a URL no celular e no PC.
   • Se abrir, deu certo. Esse é o link do jogo!
8) QR CODE (opcional):
   • No Canva: Apps > QR Code > cole a URL e gere o QR para colar no PDF.
   • Ou use https://www.qr-code-generator.com/ e baixe o PNG.
DICA: Se quiser encurtar, use bit.ly (fica bonito no PDF).
